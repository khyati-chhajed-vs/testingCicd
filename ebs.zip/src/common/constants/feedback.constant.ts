export const FEEDBACK_ENDPOINT = '/feedbacks';
