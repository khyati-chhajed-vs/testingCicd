export const UNIT_ERR = {
  UNIT_NOT_FOUND: {
    CODE: 'UNIT_NOT_FOUND',
  },
};
