export const SERVICE_REQUEST = '/service_requests';
