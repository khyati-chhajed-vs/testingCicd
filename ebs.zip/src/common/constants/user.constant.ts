export const USER_ENDPOINT = '/user';
export const USER_ERROR = {
  NOT_FOUND: {
    CODE: 'USER_NOT_FOUND',
    MESSAGE: 'USER_NOT_FOUND',
  },
};
