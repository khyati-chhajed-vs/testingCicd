export const GETUSER_ENDPOINT = '/getvcareuser';
export const CARETAKER_ID_ENDPOINT = '/:caretaker_id';
export const VCARE_LOGIN_ERROR = {
  NOT_FOUND: {
    CODE: 'NOT_FOUND',
    MESSAGE: 'NOT_FOUND',
  },
};
