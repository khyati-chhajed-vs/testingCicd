export const PLANS_ENDPOINT = '/plans';
