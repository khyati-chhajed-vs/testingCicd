export const REGION = 'ap-south-1';
export const STAGES = {
  local: 'local',
};
export const SECRETNAMES = {
  firebaseConfig: process.env.NODE_ENV + '/vianaar/firebase',
  vianaarServer: process.env.NODE_ENV + '/vianaar/server',
};
