export const GALLERY_ENDPOINT = '/gallery';
export const IMAGE_CATEGORY = { CLEANING: 'CLEANING', INVENTORY: 'INVENTORY' };
