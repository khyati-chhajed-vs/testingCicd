export const INVENTORIES_ENDPOINT = '/inventories';
