export const CLEANING_ENDPOINT = '/cleanings';
export const MIS_ENDPOINT = '/mis_summary';
