export const TESTIMONIAL_ENDPOINT = '/testimonials';
