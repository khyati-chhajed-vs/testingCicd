interface ContactParams {
  project_id: number;
}

export interface ContactRequest {
  Params: ContactParams;
}
