interface Params {
  project_id: number;
}

export interface ProjectProgressRequest {
  Params: Params;
}
