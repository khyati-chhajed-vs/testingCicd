export interface CancelRequestParam {
  project_id: number;
  unit_id: number;
  request_id: number;
}
export interface CancelAirportRequest {
  Params: CancelRequestParam;
}
