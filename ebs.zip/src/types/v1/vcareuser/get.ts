interface VcareUserRequestParam {
  caretaker_id: number;
}

export interface GetVcareUserRequest {
  Params: VcareUserRequestParam;
}
