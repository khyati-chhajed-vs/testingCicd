export interface DeleteSiteVisitRequestParams {
  project_id: number;
  unit_id: number;
  request_id: number;
}

export interface DeleteSiteVisitRequest {
  Params: DeleteSiteVisitRequestParams;
}
