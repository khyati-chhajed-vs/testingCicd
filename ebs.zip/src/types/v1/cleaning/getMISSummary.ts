export interface GetMISSummaryParams {
  project_id: number;
  unit_id: number;
}
export interface GetMISSummaryRequest {
  Params: GetMISSummaryParams;
}
