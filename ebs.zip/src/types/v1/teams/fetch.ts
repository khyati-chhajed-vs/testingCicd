interface TeamParams {
  project_id: number;
}

export interface TeamRequest {
  Params: TeamParams;
}
