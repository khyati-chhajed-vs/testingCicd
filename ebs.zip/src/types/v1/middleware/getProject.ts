export interface ProjectType {
  project_id: number;
  user_id: number;
  project_status: string;
}
