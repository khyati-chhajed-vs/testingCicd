export interface GetSurveyRequestParams {
  project_id: number;
  unit_id: number;
}

export interface GetSurveyRequest {
  Params: GetSurveyRequestParams;
}
