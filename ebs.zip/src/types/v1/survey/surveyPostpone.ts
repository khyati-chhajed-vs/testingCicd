export interface SurveyPostponeParams {
  project_id: number;
  unit_id: number;
}

export interface SurveyPostponeRequest {
  Params: SurveyPostponeParams;
}
