interface DeleteCatamaranRequestParams {
  project_id: number;
  unit_id: number;
  request_id: number;
}

export interface DeleteCatamaranRequest {
  Params: DeleteCatamaranRequestParams;
}
