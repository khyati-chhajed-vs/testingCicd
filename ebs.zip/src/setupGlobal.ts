global.LAMBDA_ENV = true;
console.log('global.LAMBDA_ENV', global.LAMBDA_ENV);
